#pragma once
#include "cinder/CinderResources.h"
#include <crtdbg.h>
#define RES_SKINNING_VERT				CINDER_RESOURCE( ../../../resources/, skinning_vert_normals.glsl, 128, GLSL  )
#define RES_SKINNING_FRAG				CINDER_RESOURCE( ../../../resources/, skinning_frag_normals.glsl, 129, GLSL  )

//#define RES_MY_RES			CINDER_RESOURCE( ../resources/, image_name.png, 128, IMAGE )




